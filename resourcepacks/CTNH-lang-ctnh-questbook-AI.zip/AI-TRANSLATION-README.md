CTNH 任务书语言包 — AI 翻译版 / AI-Translated Quest-Book Language Pack
=================================================================

仅包含任务书命名空间 `assets/ctnh/lang/`（FTB Quests 任务书文本）。
Contains ONLY the quest-book namespace assets/ctnh/lang/.

内容 / Contents
- assets/ctnh/lang/en_us.json  2813 键（英文）
- assets/ctnh/lang/ja_jp.json  2813 键（日文）
- assets/ctnh/lang/ru_ru.json  2813 键（俄文）

质量说明 / Quality Notes
- 由 AI 根据 zh_cn.json 翻译生成；机器名等术语尽量采用官方英文名
  （经 VMCT 词典与 CTNH 源码核对），ru/jp 为 AI 自行翻译。
- 键名、颜色代码(&4/&r 等)、占位符均已校验保留。
- 电力时代章节统一为 xxx era（LV Era / LV時代 / Эпоха LV），
  奖励表保留 xxx Rewards 形式。
- 社区联系方式为 Discord： https://discord.com/invite/jQpvUDsVX8
- 发布前建议人工校对。

生成于 / Generated: 2026-08-12
