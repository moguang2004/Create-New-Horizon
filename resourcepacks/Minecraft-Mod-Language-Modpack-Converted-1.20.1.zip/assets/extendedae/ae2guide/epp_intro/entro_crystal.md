---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Crystal
    icon: extendedae:entro_crystal
categories:
- entro system
item_ids:
- extendedae:entro_crystal
---

# The Entro Crystal

<Row>
<ItemImage id="extendedae:entro_crystal" scale="4"></ItemImage>
</Row>

*"Entro Crystals show the extreme strong dimensional affinity after injecting Ender Dust to Fluix Crystals, and can resonate
over space-time."*

The main crafting ingredient for most ExtendedAE items and machines. You need to use <ItemLink id="extendedae:entro_seed" /> to turn
<ItemLink id="ae2:fluix_block" /> into [Entroized Fluix Budding](./entro_budding.md), and harvest Entro Cluster to get Entro Crystals.
