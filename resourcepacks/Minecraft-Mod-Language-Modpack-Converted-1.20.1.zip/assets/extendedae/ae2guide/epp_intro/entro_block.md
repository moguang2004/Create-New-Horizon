---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Block
    icon: extendedae:entro_block
categories:
- entro system
item_ids:
- extendedae:entro_block
---

# The Entro Block

<Row>
<BlockImage id="extendedae:entro_block" scale="8"></BlockImage>
</Row>

A storage block for <ItemLink id="extendedae:entro_crystal" />.
