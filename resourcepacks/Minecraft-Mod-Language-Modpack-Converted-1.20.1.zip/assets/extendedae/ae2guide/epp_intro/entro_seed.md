---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Seed
    icon: extendedae:entro_seed
categories:
- entro system
item_ids:
- extendedae:entro_seed
---

# Entro Seed

<Row>
<ItemImage id="extendedae:entro_seed" scale="4"></ItemImage>
</Row>

These seeds contain strong Entro energy. Right click <ItemLink id="ae2:fluix_block" /> with entro seed to turn it into [Entroized Fluix Budding](./entro_budding.md)
or you can use <ItemLink id="extendedae:crystal_assembler" /> to inject the seed, but it gives lower grade [Entroized Fluix Budding](./entro_budding.md) compared
with the manual route.
