---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Extended Machine Frame
    icon: extendedae:machine_frame
categories:
- extended foundation
item_ids:
- extendedae:machine_frame
---

# The Start of ExtendedAE

<Row>
<BlockImage id="extendedae:machine_frame" scale="8"></BlockImage>
</Row>

After gathering enough <ItemLink id="extendedae:entro_crystal" />, you finally can craft the first Extended Machine Frame.
These frames are the foundation of ExtendedAE, and most block form machines in ExtendedAE will need them.
