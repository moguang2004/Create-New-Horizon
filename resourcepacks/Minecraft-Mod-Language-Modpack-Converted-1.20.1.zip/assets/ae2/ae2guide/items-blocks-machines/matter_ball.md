---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 物质球
  icon: matter_ball
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:matter_ball
---

# 物质球

<ItemImage id="matter_ball" scale="4" />

一团物质组成的球，可作为<ItemLink id="matter_cannon" />的弹药或用于生产[染色球](paintballs.md)。

由物质球模式的<ItemLink id="condenser" />聚合256个物品或256桶流体而得。
