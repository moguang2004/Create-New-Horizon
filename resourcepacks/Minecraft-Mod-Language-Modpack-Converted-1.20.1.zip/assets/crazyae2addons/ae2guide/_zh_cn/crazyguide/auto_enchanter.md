---
navigation:
  parent: crazyae2addons_index.md
  title: 自动附魔器
  icon: crazyae2addons:auto_enchanter
categories:
   - Monitoring and Automation
item_ids:
  - crazyae2addons:auto_enchanter
---

# 自动附魔器

<BlockImage id="crazyae2addons:auto_enchanter" scale="4"></BlockImage>

自动附魔器是能独立运作的附魔机器，会使用ME网络中的经验碎片自动为书和工具附魔。它的附魔方式类似于原版Minecraft和神化（Apotheosis）。此设备必需放置在标准附魔台设施下方2格处，且其附魔能力取决于书架的数目。

## 使用方法

## [视频教程](https://youtu.be/Zu213pe7Jeo&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

1. **放置自动附魔器**
   - 此设备必须放置在附魔台下方2格处。
   - 和原版一样，在附魔台周围放置书架，以提高附魔等级。

2. **放入物品**
   - 输入槽：放入需附魔的物品（工具、武器、书）。
   - 青金石槽：放入青金石（附魔必需品）。
   - 输出槽：经过附魔的物品会送到此处。

3. **前置需求**
   - 需要ME系统中存有经验碎片。
   - 经验消耗根据书架计算。

4. **选择附魔选项**
   - 在GUI内，挑选三项附魔选项之一（1到3级）。
   - 点击相应按钮选择选项。
   - GUI会显示预期的经验消耗。

5. **自动化**
   - 打开或关闭**自动供应青金石**：自动从网络中补充青金石。
   - 打开或关闭**自动供应书**：自动从网络中补充书。

## 神化支持

如果同时安装有神化：
- 自动附魔器会自动扫描周围所有书架的特殊属性，如位阶、量子化、阿卡那、魔咒线索，同时可出产宝藏型魔咒。

## 行为总概

- 如启用，可自动补充输入物品和青金石。
- 会消耗网络中的经验碎片（1 碎片 = 10 经验）。
- 只在其上方2格处存在有效附魔台时运作。
- 会基于原版Minecraft或神化附魔机制产出附魔书和附魔的物品。
- 可以消耗网络中的物品。